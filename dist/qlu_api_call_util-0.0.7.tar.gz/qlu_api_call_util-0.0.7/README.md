# QLU API CALL UTIL PACKAGE

This is a QLU API call util package which provides functionality of making HTTP requeset with retries and retry after interval.